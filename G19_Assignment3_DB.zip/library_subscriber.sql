-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subscriber`
--

DROP TABLE IF EXISTS `subscriber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriber` (
  `subscriber_id` int NOT NULL,
  `subscriber_name` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `subscriber_email` varchar(100) DEFAULT NULL,
  `subscriber_phone_number` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `status` enum('active','frozen') DEFAULT NULL,
  `registerDate` date DEFAULT NULL,
  `detailed_subscription_history` int DEFAULT NULL,
  PRIMARY KEY (`subscriber_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriber`
--

LOCK TABLES `subscriber` WRITE;
/*!40000 ALTER TABLE `subscriber` DISABLE KEYS */;
INSERT INTO `subscriber` VALUES (121212121,'Dana Nama','Dana','Dana@gmail.com','0502412255','Dana','active','2024-12-25',1),(147147147,'Mahmod Mahamed','Mahmod','Mahmod8@gmail.com','0521421424','Mahmod','active','2025-01-26',1),(202020202,'Luna Assadi','Luna','manaln2308@gmail.com','0502542122','Luna','active','2024-11-02',1),(212530828,'Nahla Abu Romi','Nahla','NahlaAboromi@gmail.com','0502898789','Nahla','active','2025-01-10',1),(213538606,'Mohamad Atamneh','Mohamad','mohamad.atamleh55@gmail.com','0525693406','Mohamad','active','2025-01-12',1),(213675549,'Fatma Dabbah','Fatma','fatima.dabbah.2003@gmail.com','0523156707','Fatma','active','2024-11-12',1),(224541552,'Hiba Abbas','Hiba','Hiba@gmail.com','0521425566','Hiba','active','2024-12-06',1),(235669987,'Malak Omari','MalakOmari','Malak87@gmail.com','0541142255','Malak1','active','2024-12-22',1),(258258258,'Lara Hassan','Lara','Lara325@gmail.com','0524121122','Lara','active','2024-12-22',1),(303030303,'Hosen Nama','Hosen','manaln2308@gmail.com','0524123625','Hosen','active','2024-12-02',1),(325273556,'Roba Hassan','Roba','roba.13.hassan@gmail.com','0525693406','Roba','active','2025-01-05',1),(325393999,'Manal Nama','Manal','manaln2308@gmail.com','0502541521','Manal','active','2024-12-14',1),(404040404,'Loren','Loren','Loren144@gmail.com','0502142111','Loren','active','2024-12-14',1),(435672981,'Maya Levi','MayaL','MayaL@gmail.com','0523456789','Maya2024','active','2024-12-05',1),(454545454,'Nour Omar','Nour','Nour@gmail.com','0524121522','Nour','active','2024-11-23',1),(456789321,'Sarah Cohen','SarahC','SarahCohen@gmail.com','0541234567','Sarah123','frozen','2024-11-03',1),(492345678,'Noah Bar','NoahB','NoahBar@gmail.com','0549873210','NoahB2024','frozen','2024-11-07',1),(497856342,'Daniel Green','DanG','DanielG@gmail.com','0559876543','DanG2024','frozen','2024-11-10',1),(505050505,'Dina','Dina','Dina@gmail.com','0524152333','Dina','frozen','2024-11-06',1),(524125633,'Anna Loaer','AnnaGa','AnnaGasr@gmail.com','0541215368','Anna412','frozen','2024-11-06',1),(578341296,'Benjamin Garcia','BenG','BenjaminG@gmail.com','0523419876','BenG2024','frozen','2024-12-01',1),(578965432,'Emma Williams','EmmaW','EmmaWilliams@gmail.com','0546547891','EmmaW123','frozen','2024-11-12',1),(584321987,'Mason Taylor','MasonT','MasonT@gmail.com','0559871234','MasonT2024','frozen','2024-11-15',1),(585123456,'Liam Brown','LiamB','LiamBrown@gmail.com','0528741234','Liam2024','frozen','2024-12-20',1),(587654321,'James Johnson','JamesJ','JamesJohnson@gmail.com','0548765432','JamesJ2024','frozen','2024-11-25',1),(589874123,'Sophia Miller','SophiaM','SophiaMiller@gmail.com','0539876543','SophiaM2024','frozen','2024-11-10',1),(590987654,'Mia Anderson','MiaA','MiaA@gmail.com','0528765432','MiaA2024','frozen','2024-11-30',1),(595432187,'William Davis','WillD','WilliamD@gmail.com','0554321987','WillD2024','frozen','2024-11-30',1),(596543218,'Isabella Martinez','IsaM','IsabellaM@gmail.com','0543218765','IsaM2024','frozen','2024-11-05',1),(596874321,'Olivia Smith','OliviaS','OliviaSmith@gmail.com','0531239876','OliviaS2024','active','2024-11-15',1),(600123456,'Ethan Taylor','EthanT','EthanTaylor@gmail.com','0521234567','EthanT2024','active','2024-11-01',1),(600234567,'Emma Johnson','EmmaJ','EmmaJohnson@gmail.com','0542345678','EmmaJ2024','active','2024-11-05',1),(600345678,'Noah Davis','NoahD','NoahDavis@gmail.com','0533456789','NoahD2024','active','2024-11-10',1),(600456789,'Ava Wilson','AvaW','AvaWilson@gmail.com','0524567890','AvaW2024','active','2024-11-15',1),(600567890,'Oliver Martinez','OliverM','OliverMartinez@gmail.com','0545678901','OliverM2024','active','2024-11-20',1),(600678901,'Sophia Lee','SophiaL','SophiaLee@gmail.com','0536789012','SophiaL2024','active','2024-11-25',1),(600789012,'James Brown','JamesB','JamesBrown@gmail.com','0527890123','JamesB2024','active','2024-11-30',1),(606060606,'Ahmad','Ahmad','Ahmad@gmail.com','0521122387','Ahmad','active','2025-01-22',1),(707070707,'Kamar','Kamar','Kamar2025@gmail.com','0502142522','Kamar','active','2024-11-15',1),(808080808,'Aya Assadi','Aya','Aya21@gmail.com','0521423622','Roba','active','2024-11-09',1),(874874874,'Jana Nama','Jana','JanaNa@gmail.com','0521425366','Jana','active','2024-11-09',1),(985985985,'Hala Omar','Hala','HalaO14@gmail.com','0558745744','Hala','active','2024-11-04',1);
/*!40000 ALTER TABLE `subscriber` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-27 22:02:34
