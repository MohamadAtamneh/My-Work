-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subscriber_changes_history`
--

DROP TABLE IF EXISTS `subscriber_changes_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriber_changes_history` (
  `change_history_id` int NOT NULL AUTO_INCREMENT,
  `subscriber_id` int DEFAULT NULL,
  `change_type` enum('password','phone','email') NOT NULL,
  `old_value` varchar(255) DEFAULT NULL,
  `new_value` varchar(255) DEFAULT NULL,
  `change_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`change_history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriber_changes_history`
--

LOCK TABLES `subscriber_changes_history` WRITE;
/*!40000 ALTER TABLE `subscriber_changes_history` DISABLE KEYS */;
INSERT INTO `subscriber_changes_history` VALUES (1,325393999,'phone','0502541523','0502541521','2025-01-10 20:02:30'),(2,202020202,'phone','0502456669','0502542122','2025-01-16 15:24:04'),(3,303030303,'email','Hosen@gmail.com','Hosen142@gmail.com','2025-01-09 03:19:11'),(4,404040404,'phone','0502142121','0502142142','2024-12-27 14:21:02'),(5,404040404,'email','Loren@gmail.com','Loren145@gmail.com','2025-01-26 03:21:09'),(6,404040404,'phone','0502142142','0502142111','2024-12-17 13:31:24'),(7,404040404,'email','Loren145@gmail.com','Loren144@gmail.com','2025-01-27 03:21:24'),(8,258258258,'email','Lara@gmail.com','Lara325@gmail.com','2024-12-01 16:42:07'),(9,606060606,'phone','0524122368','0521122387','2025-01-27 01:22:26'),(10,235669987,'password','Malak123','Malak1','2025-01-27 13:26:19');
/*!40000 ALTER TABLE `subscriber_changes_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-27 22:02:34
