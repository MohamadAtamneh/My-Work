-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `most_borrowed_report_data`
--

DROP TABLE IF EXISTS `most_borrowed_report_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `most_borrowed_report_data` (
  `report_id` int NOT NULL AUTO_INCREMENT,
  `year` int DEFAULT NULL,
  `month` int DEFAULT NULL,
  `report_data` json DEFAULT NULL,
  `generation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `most_borrowed_report_data`
--

LOCK TABLES `most_borrowed_report_data` WRITE;
/*!40000 ALTER TABLE `most_borrowed_report_data` DISABLE KEYS */;
INSERT INTO `most_borrowed_report_data` VALUES (169,2024,11,'[[7, \"b\", 9], [9, \"The Authoritative Calvin and Hobbes\", 2], [24, \"Sapiens: A Brief History of Humankind\", 2], [19, \"To Kill a Mockingbird\", 2], [5, \"The Secret Garden\", 1], [12, \"King of Sloth\", 1], [20, \"Harry Potter and the Sorcerer\'s Stone\", 1], [33, \"A People’s History of the United States\", 1], [14, \"The Silent Patient\", 1], [25, \"The Girl with the Dragon Tattoo\", 1]]','2025-01-27 19:32:57'),(170,2024,12,'[[4, \"Game Of Thrones\", 14], [7, \"b\", 11], [5, \"The Secret Garden\", 6], [18, \"1984\", 3], [19, \"To Kill a Mockingbird\", 3], [24, \"Sapiens: A Brief History of Humankind\", 2], [31, \"Guns, Germs, and Steel\", 2], [6, \"BoneShaker\", 2], [33, \"A People’s History of the United States\", 2], [34, \"The Wright Brothers\", 2]]','2025-01-27 19:32:57');
/*!40000 ALTER TABLE `most_borrowed_report_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-27 22:02:32
