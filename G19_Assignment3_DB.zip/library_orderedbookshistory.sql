-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orderedbookshistory`
--

DROP TABLE IF EXISTS `orderedbookshistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderedbookshistory` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `subscriber_id` int DEFAULT NULL,
  `book_id` int DEFAULT NULL,
  `Order_date` datetime DEFAULT NULL,
  `order_status` enum('Pending','Fulfilled','Cancelled') DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderedbookshistory`
--

LOCK TABLES `orderedbookshistory` WRITE;
/*!40000 ALTER TABLE `orderedbookshistory` DISABLE KEYS */;
INSERT INTO `orderedbookshistory` VALUES (28,325393999,33,'2025-01-09 03:57:36','Fulfilled'),(29,213675549,21,'2025-01-07 05:57:56','Fulfilled'),(31,325393999,5,'2025-01-23 19:02:17','Fulfilled'),(32,213675549,5,'2025-01-13 10:17:01','Fulfilled'),(33,213675549,4,'2024-12-15 19:45:54','Fulfilled'),(34,202020202,24,'2024-12-28 16:50:54','Fulfilled'),(35,202020202,7,'2024-12-13 20:55:21','Fulfilled'),(36,325393999,9,'2024-01-13 23:11:28','Fulfilled'),(37,303030303,24,'2025-01-13 21:18:08','Fulfilled'),(38,213675549,33,'2025-01-26 22:15:40','Fulfilled'),(39,325393999,7,'2025-01-14 03:18:02','Fulfilled'),(40,303030303,14,'2025-01-15 03:29:46','Fulfilled'),(41,202020202,12,'2025-01-17 17:36:39','Fulfilled'),(42,202020202,31,'2024-12-17 17:53:07','Fulfilled'),(43,325393999,28,'2025-01-08 01:44:48','Fulfilled'),(44,325393999,23,'2025-01-16 01:48:42','Fulfilled'),(45,325393999,7,'2024-12-18 01:56:36','Fulfilled'),(46,202020202,8,'2025-01-20 03:08:29','Fulfilled'),(59,202020202,7,'2024-12-24 00:42:50','Fulfilled'),(60,213675549,7,'2025-01-20 00:53:14','Fulfilled'),(61,325393999,3,'2025-01-20 01:15:45','Fulfilled'),(62,202020202,3,'2025-01-20 12:07:03','Fulfilled'),(64,202020202,19,'2025-01-21 22:49:35','Fulfilled'),(67,303030303,18,'2025-01-25 17:18:01','Fulfilled'),(68,325393999,9,'2025-01-12 21:57:43','Fulfilled'),(69,325393999,6,'2024-12-26 12:03:35','Fulfilled'),(70,325393999,21,'2025-01-26 22:11:52','Fulfilled'),(71,325393999,34,'2024-12-02 23:14:31','Fulfilled'),(72,325393999,20,'2025-01-26 22:23:55','Fulfilled'),(73,303030303,3,'2025-01-27 10:58:51','Fulfilled'),(74,202020202,12,'2025-01-14 12:25:21','Cancelled'),(75,325393999,26,'2024-12-13 14:20:45','Cancelled'),(76,404040404,29,'2024-12-26 12:15:48','Cancelled');
/*!40000 ALTER TABLE `orderedbookshistory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-27 22:02:32
